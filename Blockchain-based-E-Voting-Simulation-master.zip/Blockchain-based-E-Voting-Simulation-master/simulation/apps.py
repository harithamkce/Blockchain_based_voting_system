from django.apps import AppConfig


class SimulationConfig(AppConfig):
    name = 'simulation'
